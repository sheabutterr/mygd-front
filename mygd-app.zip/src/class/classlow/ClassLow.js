import LowA from "./LowA";
import LowB from "./LowB";
import LowC from "./LowC";

const ClassLow = ({history}) => { 

    return (
        <>
            <LowA />
            <LowB />
            <LowC />            
        </>
    );
}

export default ClassLow;