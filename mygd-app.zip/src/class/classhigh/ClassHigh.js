import HighA from "./HighA";
import HighB from "./HighB";
import HighC from "./HighC";

const ClassHigh = ({history}) => {

    return (
        <>
            <HighA />
            <HighB />
            <HighC />
            
        </>
    );
}

export default ClassHigh;